import React from "react";
import dataRoadmap from "../assets/fake-data/data-roadmap";
import PageTitle from "../components/pagetitle";
import RoadMap from "../features/roadmap";

function RoadMapOne() {
  return (
    <div className="bg-[#0c1226] min-h-screen text-white font-figtree">
      {/* Page Title Section */}
      <section className="relative py-28 text-center bg-[#141A31]">
        <h1 className="text-5xl md:text-6xl font-bold uppercase tracking-wider text-white">
          Roadmap
        </h1>
        <div className="mt-4 w-24 h-1 bg-[#14C2A3] mx-auto"></div>
      </section>

      {/* Roadmap Section */}
      <section className="py-20 px-4 max-w-7xl mx-auto">
        <RoadMap data={dataRoadmap} />
      </section>
    </div>
  );
}

export default RoadMapOne;
