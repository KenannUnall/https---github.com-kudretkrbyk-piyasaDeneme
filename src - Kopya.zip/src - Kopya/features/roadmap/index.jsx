import React, { useState } from "react";

import RoadMapItem from "./roadmap-item";

function RoadMap({ data }) {
  const [dataBlock] = useState({
    subtitle: "ROADMAP",
    title: "cybox Timeline",
  });

  return (
    <section className="relative bg-[url('/assets/images/background/bg1roadmap.png')] bg-no-repeat bg-bottom bg-cover py-20 md:py-24">
      <div className="absolute inset-0 bg-black/40 z-0"></div>
      <div className="relative z-10 max-w-7xl mx-auto px-4">
        <div
          className="text-center mb-14"
          data-aos="fade-up"
          data-aos-duration="800"
        >
          <p className="text-[#14C2A3] text-lg font-semibold uppercase mb-2">
            {dataBlock.subtitle}
          </p>
          <h2 className="text-white text-4xl md:text-5xl font-bold uppercase tracking-wide">
            {dataBlock.title}
          </h2>
        </div>

        <div className="relative max-w-5xl mx-auto flex flex-wrap justify-between px-4 pt-8 overflow-y-auto h-[937px] scrollbar-hide cursor-s-resize">
          {/* Central timeline line */}
          <div className="absolute top-[46%] left-1/2 w-1.5 h-[124%] bg-[#14C2A3] transform -translate-x-1/2 z-[1]" />
          <div className="absolute top-0 left-1/2 w-1.5 h-1/2 bg-[#565660] transform -translate-x-1/2 z-0" />

          {data.map((item) => (
            <RoadMapItem key={item.id} item={item} />
          ))}
        </div>
      </div>
    </section>
  );
}

export default RoadMap;
