import React from "react";

function RoadMapItem({ item }) {
  const isLeft = item.positon === "left";
  const isRight = item.positon === "right";

  return (
    <div
      className={`relative w-[403px] mb-[115px] ${
        isRight ? "mt-[165px] -mb-[46px]" : ""
      } ${isLeft ? "mt-0" : ""}`}
      data-aos="zoom-in"
      data-aos-duration="1200"
    >
      {/* Connector lines and dots */}
      <div
        className={`absolute top-1/2 ${
          isLeft ? "right-[-52px]" : "left-[-52px]"
        } w-[52px] h-[2px] bg-[#14C2A3]`}
      />
      <div
        className={`absolute top-1/2 ${
          isLeft ? "right-[-72px]" : "left-[-72px]"
        } w-5 h-5 bg-[#14C2A3]`}
      />

      <div
        className={`relative bg-[#0e2431] p-5 transition-shadow duration-300 hover:shadow-[0_0px_32px_rgba(34,183,143,0.5)] rounded-md ${
          item.style === "normal" ? "bg-[#13182b]" : ""
        }`}
      >
        <h5 className="text-xl font-bold text-white mb-4">{item.time}</h5>
        <ul className="space-y-2">
          {item.list.map((li, idx) => (
            <li
              key={idx}
              className="relative pl-6 text-[#B9B9BF] text-sm leading-relaxed"
            >
              <span className="absolute left-1 top-2 w-1 h-1 rounded-full bg-[#B9B9BF]" />
              {li.text}
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default RoadMapItem;
